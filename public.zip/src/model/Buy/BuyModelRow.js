import { Button } from "@material-ui/core";
import React from "react";

function BuyModelRow() {
  return (
    <Grid>
      <Button>Limit</Button>
      <Button>Limit</Button>
      <Button>Stop Limit</Button>
    </Grid>
  );
}
export default BuyModelRow;
