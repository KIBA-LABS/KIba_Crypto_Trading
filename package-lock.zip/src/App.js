import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import "./App.css";
import Employer_Registration from "./components/pages/Employer/Employer_Registration";
import Home from "./components/pages/Home";

import LoginModal from "./components/pages/LoginModal";
import LoginForm from "./components/pages/Employer/LoginForm";
import Appbar from "./components/common/Appbar";

function App() {
  return (
    <BrowserRouter>
      <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
      <div className="App">
        <Appbar></Appbar>
      </div>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route
          path="/employer_registration"
          element={<Employer_Registration />}
        />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/login_modal" element={<LoginModal />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
