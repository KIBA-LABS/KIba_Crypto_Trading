import React, { Fragment } from "react";
import { ErrorMessage, Field, Form, Formik } from "formik";
import * as yup from "yup";
import axios from "axios";
import { Link } from "react-router-dom";
import { useStyles } from "../../common/style";
import Appbar from "../../common/Appbar";
import Footer from "../../common/Footer";

//import { Button } from "@material-ui/core";
//import Employer_Registration from "./Employer/Employer_Registration";

const LoginForm = () => {
  const classes = useStyles();

  const formInitialSchema = {
    email: "",
    password: "",
  };

  let schema = yup.object().shape({
    email: yup
      .string()
      .required("Email is required")
      .email("Please enter valid Email"),
    password: yup.string().required("Password is required").min(8),
  });

  const handleFormSubmit = (values) => {
    console.log("Submitted Values", values);
  };
  return (
    <Fragment>
      <div className="container">
        {/* <div className="col-md-12 offset-md-12"> */}
        <div
          className="col-md-6 offset-md-6"
          style={{
            width: "100%",
            marginTop: "200px",
            height: "400px",
          }}
        >
          <lottie-player
            src="https://assets3.lottiefiles.com/private_files/lf30_gonpfxdh.json"
            background="transparent"
            speed="1"
            style="width: 300px; height: 300px;"
            loop
            controls
            autoplay
          ></lottie-player>
        </div>
        <div className="col-md-6 offset-md-6">
          <Formik
            initialValues={formInitialSchema}
            validationSchema={schema}
            onSubmit={(values) => handleFormSubmit(values)}
          >
            <Form
              style={{
                width: "100%",
                marginTop: "200px",
                height: "400px",
                boxShadow: "0px 5px 10px 0px rgba(0, 0, 0, 0.3)",
              }}
            >
              <div className="col-md-12 mt-2">
                <br />
                <b style={{ marginLeft: "50%", marginTop: "50px" }}>
                  Need an account?{" "}
                  <Link to="/employer_registration">Sign UP</Link>
                </b>
                {/* <a href="Employer_Registration.js">Sign up</a> */}
                <br />
                <br />
                <Field
                  type="text"
                  name="email"
                  placeholder="Enter Your Email"
                  className="form-control"
                />
                <p className="text-danger">
                  <ErrorMessage name="email" />
                </p>
              </div>
              <div className="col-md-12 mt-4">
                <Field
                  type="text"
                  name="password"
                  placeholder="Enter Your Password"
                  className="form-control"
                />
                <p className="text-danger">
                  <ErrorMessage name="password" />
                </p>
              </div>
              <div className="col-md-12 mt-4">
                <button
                  type="submit"
                  className="btn btn-primary btn-block"
                  style={{
                    background:
                      "linear-gradient(135deg, #13547a 10%, #80d0c7 100%)",
                  }}
                >
                  LOGIN
                </button>
              </div>
              <br />
              <b style={{ marginLeft: "63%" }}>
                <Link to="#">Forget password?</Link>
              </b>
              <br />
              <br />
            </Form>
          </Formik>
        </div>
      </div>
      {/* </div> */}
      {/* </div>
        </div>
      </div> */}

      <div>
        <Footer />
      </div>
    </Fragment>
  );
};

export default LoginForm;
